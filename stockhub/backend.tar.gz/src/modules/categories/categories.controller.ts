import { Controller, Get, Post, Put, Delete, Param, Body, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth } from '@nestjs/swagger';
import { CategoriesService } from './categories.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { Category } from './entities/category.entity';

@ApiTags('类目管理')
@Controller('categories')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class CategoriesController {
  constructor(private readonly categoriesService: CategoriesService) {}

  @Post('initialize')
  @ApiOperation({ summary: '初始化类目数据' })
  @ApiResponse({ status: 201, description: '初始化成功' })
  async initialize() {
    await this.categoriesService.initializeCategories();
    return { message: '类目数据初始化成功' };
  }

  @Get()
  @ApiOperation({ summary: '获取所有类目' })
  @ApiResponse({ status: 200, description: '获取成功' })
  findAll() {
    return this.categoriesService.findAll();
  }

  @Get(':id')
  @ApiOperation({ summary: '获取类目详情' })
  @ApiResponse({ status: 200, description: '获取成功' })
  @ApiResponse({ status: 404, description: '类目不存在' })
  findOne(@Param('id') id: string) {
    return this.categoriesService.findOne(id);
  }

  @Post()
  @ApiOperation({ summary: '创建类目（管理员）' })
  @ApiResponse({ status: 201, description: '创建成功' })
  async create(@Body() data: Partial<Category>) {
    return this.categoriesService.create(data);
  }

  @Put(':id')
  @ApiOperation({ summary: '更新类目（管理员）' })
  @ApiResponse({ status: 200, description: '更新成功' })
  @ApiResponse({ status: 404, description: '类目不存在' })
  async update(@Param('id') id: string, @Body() data: Partial<Category>) {
    return this.categoriesService.update(id, data);
  }

  @Delete(':id')
  @ApiOperation({ summary: '删除类目（管理员）' })
  @ApiResponse({ status: 200, description: '删除成功' })
  @ApiResponse({ status: 404, description: '类目不存在' })
  async delete(@Param('id') id: string) {
    await this.categoriesService.delete(id);
    return { message: '删除成功' };
  }
}
