import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Category } from './entities/category.entity';

@Injectable()
export class CategoriesService {
  constructor(
    @InjectRepository(Category)
    private categoriesRepository: Repository<Category>,
  ) {}

  /**
   * 初始化12个类目数据
   */
  async initializeCategories(): Promise<void> {
    const count = await this.categoriesRepository.count();
    if (count > 0) {
      console.log('类目数据已存在，跳过初始化');
      return;
    }

    const categories = [
      { name: '电子元器件', name_en: 'Electronic Components', description: '各类电子元器件、IC芯片、被动元件等', icon: '💡', totalSales: 15000000 },
      { name: '工业设备', name_en: 'Industrial Equipment', description: '工业生产设备、自动化生产线设备', icon: '🏭', totalSales: 28000000 },
      { name: '机械设备', name_en: 'Machinery', description: '各类机械加工设备、数控机床等', icon: '⚙️', totalSales: 9500000 },
      { name: '服装鞋帽', name_en: 'Apparel & Footwear', description: '各类服装、鞋类、帽子等', icon: '👕', totalSales: 42000000 },
      { name: '家居用品', name_en: 'Home & Living', description: '家具、家居装饰品、日用品等', icon: '🏠', totalSales: 18000000 },
      { name: '食品饮料', name_en: 'Food & Beverages', description: '各类食品、饮料、零食等', icon: '🍎', totalSales: 67000000 },
      { name: '运动户外', name_en: 'Sports & Outdoors', description: '运动器材、户外用品、健身器材等', icon: '⚽', totalSales: 12000000 },
      { name: '美妆护肤', name_en: 'Beauty & Skincare', description: '化妆品、护肤品、美容工具等', icon: '💄', totalSales: 35000000 },
      { name: '玩具礼品', name_en: 'Toys & Gifts', description: '玩具、礼品、工艺品等', icon: '🎁', totalSales: 8900000 },
      { name: '汽车配件', name_en: 'Auto Parts', description: '汽车配件、维修工具、车载用品等', icon: '🚗', totalSales: 21000000 },
    ];

    for (const categoryData of categories) {
      const category = this.categoriesRepository.create({
        ...categoryData,
        slug: this.generateSlug(categoryData.name),
      });
      await this.categoriesRepository.save(category);
    }

    console.log(`已初始化 ${categories.length} 个类目`);
  }

  /**
   * 生成URL slug
   */
  private generateSlug(name: string): string {
    return name
      .toLowerCase()
      .trim()
      .replace(/[\s\W-]+/g, '-')
      .replace(/-+/g, '-');
  }

  /**
   * 获取所有类目
   */
  async findAll() {
    return this.categoriesRepository.find({
      select: ['id', 'name', 'name_en', 'description', 'slug', 'icon', 'totalSales'],
      order: { id: 'ASC' },
    });
  }

  /**
   * 获取单个类目
   */
  async findOne(id: string) {
    return this.categoriesRepository.findOne({
      where: { id },
    });
  }

  /**
   * 根据ID列表获取类目
   */
  async findByIds(ids: string[]) {
    return this.categoriesRepository.find({
      where: ids.map(id => ({ id })),
    });
  }

  /**
   * 创建类目
   */
  async create(data: Partial<Category>) {
    const category = this.categoriesRepository.create(data);
    return this.categoriesRepository.save(category);
  }

  /**
   * 更新类目
   */
  async update(id: string, data: Partial<Category>) {
    await this.categoriesRepository.update(id, data);
    return this.findOne(id);
  }

  /**
   * 删除类目
   */
  async delete(id: string) {
    return this.categoriesRepository.delete(id);
  }
}
