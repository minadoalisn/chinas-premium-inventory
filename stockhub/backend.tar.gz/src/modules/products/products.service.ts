import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Like } from 'typeorm';
import { TranslateService } from '../../common/translate/translate.service';
import { Product } from './entities/product.entity';

@Injectable()
export class ProductsService {
  constructor(
    @InjectRepository(Product)
    private productsRepository: Repository<Product>,
    private translateService: TranslateService,
  ) {}

  /**
   * 创建商品
   */
  async create(
    userId: string,
    merchantId: string,
    createData: Partial<Product>
  ): Promise<Product> {
    const product = this.productsRepository.create({
      ...createData,
      merchantId,
      status: 'pending', // 新建商品默认待审核
    });

    return this.productsRepository.save(product);
  }

  /**
   * 获取商品列表（简化版）
   */
  async findAll(params: {
    page?: number;
    limit?: number;
    search?: string;
    category?: string;
    minPrice?: number;
    maxPrice?: number;
    sort?: 'newest' | 'price_asc' | 'price_desc';
    clientType?: 'domestic' | 'overseas';
    merchantId?: string;
  }) {
    const {
      page = 1,
      limit = 20,
      search,
      category,
      minPrice,
      maxPrice,
      sort = 'newest',
      clientType = 'domestic',
      merchantId,
    } = params;

    const queryBuilder = this.productsRepository.createQueryBuilder('product');

    // 客户端类型筛选
    if (clientType === 'overseas') {
      // 国际端：只显示已审核通过、允许海外展示的商品
      queryBuilder.andWhere('product.status = :status', { status: 'approved' });
      queryBuilder.andWhere('product.displayOverseas = :displayOverseas', { displayOverseas: true });
    } else {
      // 国内端：如果是商家，显示自己的所有商品；否则显示所有已审核的？
      if (merchantId) {
        queryBuilder.andWhere('product.merchantId = :merchantId', { merchantId });
      } else {
        queryBuilder.andWhere('product.status IN (:...statuses)', { statuses: ['pending', 'approved', 'rejected'] });
      }
    }

    // 搜索条件
    if (search) {
      queryBuilder.andWhere(
        '(product.title LIKE :search OR product.description LIKE :search)',
        { search: `%${search}%` }
      );
    }

    // 分类筛选
    if (category) {
      queryBuilder.andWhere('product.categoryId = :categoryId', { categoryId: category });
    }

    // 价格范围筛选
    if (minPrice) {
      queryBuilder.andWhere('product.priceDomestic >= :minPrice', { minPrice });
    }
    if (maxPrice) {
      queryBuilder.andWhere('product.priceDomestic <= :maxPrice', { maxPrice });
    }

    // 排序
    switch (sort) {
      case 'price_asc':
        queryBuilder.orderBy('product.priceDomestic', 'ASC');
        break;
      case 'price_desc':
        queryBuilder.orderBy('product.priceDomestic', 'DESC');
        break;
      case 'newest':
      default:
        queryBuilder.orderBy('product.createdAt', 'DESC');
        break;
    }

    // 分页
    const total = await queryBuilder.getCount();
    queryBuilder.skip((page - 1) * limit).take(limit);

    const data = await queryBuilder.getMany();

    return {
      success: true,
      data,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  /**
   * 获取商品详情
   */
  async findOne(id: string): Promise<Product> {
    const product = await this.productsRepository.findOne({ where: { id } });
    if (!product) {
      throw new NotFoundException('商品不存在');
    }
    return product;
  }

  /**
   * 更新商品
   */
  async update(
    id: string,
    userId: string,
    updateData: Partial<Product>
  ): Promise<Product> {
    const product = await this.findOne(id);

    // 检查权限（暂时跳过）
    // if (product.merchantId !== userId) {
    //   throw new ForbiddenException('只能修改自己的商品');
    // }

    // 库存变动逻辑：库存为0时自动下架国际端
    if (updateData.stockQty !== undefined && Number(updateData.stockQty) <= 0) {
      updateData.displayOverseas = false;
    } else if (updateData.stockQty !== undefined && Number(updateData.stockQty) > 0 && product.status === 'approved') {
      // 库存恢复且已审核，自动上架国际端
      updateData.displayOverseas = true;
    }

    await this.productsRepository.update(id, updateData);
    return this.findOne(id);
  }

  /**
   * 删除商品
   */
  async remove(id: string, userId: string): Promise<void> {
    const product = await this.findOne(id);

    // 检查权限（暂时跳过）
    // if (product.merchantId !== userId) {
    //   throw new ForbiddenException('只能删除自己的商品');
    // }

    await this.productsRepository.delete(id);
  }

  /**
   * 审核商品（管理员）
   */
  async approve(id: string): Promise<Product> {
    const product = await this.findOne(id);
    product.status = 'approved';
    product.approvedAt = new Date();
    // 审核通过且库存大于0时，自动上架国际端
    if (product.stockQty > 0) {
      product.displayOverseas = true;
    }

    // 自动翻译标题和描述到英文（如果没有）
    if (!product.titleEn && product.title) {
      product.titleEn = await this.translateService.translateText(product.title, 'en', 'zh');
    }
    if (!product.descriptionEn && product.description) {
      product.descriptionEn = await this.translateService.translateText(product.description, 'en', 'zh');
    }

    return this.productsRepository.save(product);
  }

  /**
   * 拒绝商品（管理员）
   */
  async reject(id: string): Promise<Product> {
    const product = await this.findOne(id);
    product.status = 'rejected';
    product.displayOverseas = false; // 审核拒绝时自动下架国际端
    return this.productsRepository.save(product);
  }

  /**
   * 获取相似商品
   */
  async getSimilar(id: string, limit: number = 5): Promise<Product[]> {
    const product = await this.findOne(id);
    
    return this.productsRepository
      .createQueryBuilder('product')
      .where('product.categoryId = :categoryId', { categoryId: product.categoryId })
      .andWhere('product.status = :status', { status: 'approved' })
      .andWhere('product.id != :id', { id })
      .orderBy('product.stockQty', 'DESC')
      .take(limit)
      .getMany();
  }
}
