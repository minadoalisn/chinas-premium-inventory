<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElRow, ElCol, ElCard, ElStatistic, ElTable, ElProgress, ElTag } from 'element-plus'

// 统计数据
const stats = ref({
  totalUsers: 0,
  totalProducts: 0,
  totalMerchants: 0,
  totalDemands: 0,
  pendingProducts: 0,
  pendingDemands: 0,
  matchedDemands: 0,
  thisMonthOrders: 0,
  thisMonthRevenue: 0,
})

// 热门商品
const topProducts = ref<any[]>([])

// 趋势类目
const topCategories = ref<any[]>([])

// 最新用户
const recentUsers = ref<any[]>([])

// 加载中
const loading = ref(false)

// 获取统计数据
const fetchStats = async () => {
  loading.value = true
  try {
    // 并行获取各类数据
    const [usersRes, productsRes, merchantsRes, demandsRes] = await Promise.all([
      fetch('http://localhost:3000/api/users'),
      fetch('http://localhost:3000/api/products'),
      fetch('http://localhost:3000/api/merchants'),
      fetch('http://localhost:3000/api/demands'),
    ])

    const usersData = usersRes.ok ? await usersRes.json() : {}
    const productsData = productsRes.ok ? await productsRes.json() : {}
    const merchantsData = merchantsRes.ok ? await merchantsRes.json() : {}
    const demandsData = demandsRes.ok ? await demandsRes.json() : {}

    stats.value = {
      totalUsers: usersData.data?.length || 0,
      totalProducts: productsData.data?.length || 0,
      totalMerchants: merchantsData.data?.length || 0,
      totalDemands: demandsData.data?.length || 0,
      pendingProducts: productsData.data?.filter((p: any) => p.status === 'pending').length || 0,
      pendingDemands: demandsData.data?.filter((d: any) => d.status === 'open').length || 0,
      matchedDemands: demandsData.data?.filter((d: any) => d.status === 'matched').length || 0,
      thisMonthOrders: 0,
      thisMonthRevenue: 0,
    }

    // 模拟一些热门商品（从products中取前5个）
    if (productsData.data?.data?.length > 0) {
      topProducts.value = productsData.data.data.slice(0, 5)
    }

    // 模拟热门类目（假设每个类目的商品数量）
    topCategories.value = [
      { id: 1, name: '电子元器件', count: 15 },
      { id: 2, name: '集成电路', count: 12 },
      { id: 3, name: '被动元件', count: 10 },
      { id: 5, name: '工业设备', count: 8 },
      { id: 6, name: '自动化设备', count: 6 },
    ]

    // 模拟最近用户
    recentUsers.value = usersData.data?.data?.slice(0, 5) || []

  } catch (error) {
    console.error('获取统计数据失败:', error)
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  fetchStats()
})
</script>

<template>
  <div class="stats-page">
    <h2>数据统计</h2>
    
    <!-- 概览统计 -->
    <el-row :gutter="20" class="stat-overview">
      <el-col :xs="24" :sm="12" :md="8" :lg="6">
        <el-card>
          <el-statistic :value="stats.totalUsers" title="用户总数" />
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="12" :md="8" :lg="6">
        <el-card>
          <el-statistic :value="stats.totalProducts" title="商品总数" />
        </el-card>
      </el-col>
      <el-col :xs="24" :el-sm="12" :md="8" :lg="6">
        <el-card>
          <el-statistic :value="stats.totalMerchants" title="商户总数" />
        </el-card>
      </el-col>
      <el-col :xs="24" :el-sm="12" :md="8 :lg="6">
        <el-card>
          <el-statistic :value="stats.totalDemands" title="求购总数" />
        </el-card>
      </el-col>
    </el-row>

    <!-- 业务指标 -->
    <el-row :gutter="20" class="stat-business">
      <el-col :xs="24" :sm="12" :md="12">
        <el-card>
          <div class="stat-title">待处理商品</div>
          <el-statistic :value="stats.pendingProducts">
            <template #suffix>
              <span class="stat-text">/{{ Math.round(stats.pendingProducts / stats.totalProducts * 100) }}%</span>
            </template>
          </el-statistic>
          <el-progress
            :percentage="Math.round(stats.pendingProducts / stats.totalProducts * 100)"
            :color="'#909399'"
            :stroke-width="6"
          />
        </el-card>
      </el-col>
      <el-col :xs="24" :el-sm="12" :md="12">
        <el-card>
          <div class="stat-title">待处理求购</div>
          <el-statistic :value="stats.pendingDemands">
            <template #suffix>
              <span class="stat-text">/{{ Math.round(stats.pendingDemands / stats.totalDemands * 100) }}%</span>
            </template>
          </el-statistic>
          <el-progress
            :percentage="Math.round(stats.pendingDemands / stats.totalDemands * 100)"
            :color="'f56c6c'"
            :stroke-width="6"
          />
        </el-card>
      </el-col>
      <el-col>
      <el-col :xs="24" :el-sm="12" :md="12">
        <el-card>
          <div class="stat-title">已匹配求购</div>
          <el-statistic :value="stats.matchedDemands">
            <template #suffix>
              <span class="stat-text">/{{ Math.round(stats.matchedDemands / stats.totalDemands * 100) }}%</span>
            </template>
          </el-statistic>
          <el-progress
            :percentage="Math.round(stats.matchedDemands / stats.totalDemands * 100)"
            :color="'67c23a'"
            :stroke-width="6"
          />
        </el-card>
      </el-col>
    </el-row>

    <!-- 热门商品 -->
    <el-card class="top-section">
      <template #header>
        <span class="card-title">热门商品</span>
        <el-tag size="small">TOP 5</el-tag>
      </template>
      <div v-loading="loading">
        <el-row :gutter="20">
          <el-col :xs="24" :sm="12" :md="8" v-for="item in topProducts" :key="item.id">
            <el-card :body-style="{ padding: '12px' }">
              <h4>{{ item.title }}</h4>
              <p class="price">¥{{ Number(item.priceDomestic).toLocaleString() }}</p>
              <p class="stock">库存: {{ item.stockQty }}</p>
              <el-tag>{{ item.status === 'approved' ? '已上架' : '待审核' }}</el-tag>
            </el-card>
          </el-col>
        </el-row>
      </div>
    </el-card>

    <!-- 趋势类目 -->
    <el-card class="top-section">
      <template #header>
        <span class="card-title">热门类目</span>
      </template>
      <div v-loading="loading">
        <el-table :data="topCategories" style="width: 100%">
          <el-table-column prop="name" label="类目名称" />
          <el-table-column prop="count" label="商品数量" />
        </el-table>
      </div>
    </el-card>

    <!-- 最近用户 -->
    <el-card class="top-section">
      <template #header>
        <span class="card-title">最近用户</span>
        <el-tag size="small">最新注册</el-tag>
      </template>
      <div v-loading="loading">
        <el-table :data="recentUsers" style="width: 100%">
          <el-table-column prop="name" label="用户" />
          <el-table-column prop="phone" label="手机号" />
          <el-table-column prop="role" label="角色">
            <template #default="{ row }">
              <el-tag :type="row.role === 'merchant' ? 'success' : row.role === 'admin' ? 'warning' : 'primary'">
                {{ row.role === 'merchant' ? '商户' : row.role === 'admin' ? '管理员' : '买家' }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="createdAt" label="注册时间">
            <template #default="{ row }">
              {{ new Date(row.createdAt).toLocaleString('zh-CN') }}
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-card>

    <!-- 操作说明 -->
    <el-alert type="info" :closable="false" show-icon>
      <template #title>
        <span>数据说明</span>
      </template>
      <p>以上数据为实时统计，每小时更新一次。</p>
      <p>统计数据包含：用户、商品、商户、求购等核心业务数据。</p>
    </el-alert>
  </div>
</template>

<style scoped>
.stats-page {
  padding: 20px;
  max-width: 1400px;
  margin: 0 auto;
}

.stat-overview {
  margin-bottom: 20px;
}

.stat-business {
  margin-bottom: 20px;
}

.top-section {
  margin-bottom: 20px;
}

.card-title {
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 12px;
}

.stat-text {
  color: #909399;
  font-size: 12px;
}

.el-card {
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}

.el-card :deep(.el-card__header) {
  border-bottom: 1px solid #f0f0f0;
}

.el-progress {
  margin-bottom: 12px;
}
</style>
