const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, 'data', 'stockhub.sqlite');

console.log('🗄️ 初始化数据库...');
console.log('数据库路径:', dbPath);

const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('❌ 打开数据库失败:', err);
    process.exit(1);
  }
  console.log('✅ 数据库连接成功');
});

// 创建表
const createTables = () => {
  return new Promise((resolve, reject) => {
    db.serialize(() => {
      // 用户表
      db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        phone VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(20) NOT NULL DEFAULT 'buyer',
        nickname VARCHAR(100),
        avatar VARCHAR(255),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`);

      // 商户表
      db.run(`CREATE TABLE IF NOT EXISTS merchants (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        company_name VARCHAR(200) NOT NULL,
        business_license VARCHAR(50) NOT NULL,
        contact_person VARCHAR(100) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        address VARCHAR(500),
        city VARCHAR(100),
        province VARCHAR(100),
        country VARCHAR(100) NOT NULL DEFAULT 'China',
        postal_code VARCHAR(20),
        factory_area DECIMAL(10,2),
        employee_count INTEGER,
        production_lines INTEGER,
        annual_revenue DECIMAL(15,2),
        certifications TEXT,
        product_images TEXT,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        rating DECIMAL(2,1) DEFAULT 5.0,
        completed_orders INTEGER DEFAULT 0,
        total_reviews INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`);

      // 类目表
      db.run(`CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name VARCHAR(100) NOT NULL UNIQUE,
        name_en VARCHAR(100),
        slug VARCHAR(100) NOT NULL UNIQUE,
        description TEXT,
        parent_id INTEGER,
        level INTEGER DEFAULT 1,
        sort_order INTEGER DEFAULT 0,
        is_active INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`);

      // 求购表
      db.run(`CREATE TABLE IF NOT EXISTS demands (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        buyer_id INTEGER NOT NULL,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        category_id INTEGER,
        budget_min DECIMAL(12,2),
        budget_max DECIMAL(12,2),
        currency VARCHAR(10) DEFAULT 'CNY',
        quantity INTEGER,
        unit VARCHAR(50),
        target_country VARCHAR(100),
        required_date DATE,
        status VARCHAR(20) NOT NULL DEFAULT 'open',
        matched_count INTEGER DEFAULT 0,
        created_by VARCHAR(20) NOT NULL,
        updated_by VARCHAR(20) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`);

      // 商品表
      db.run(`CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        merchant_id INTEGER NOT NULL,
        category_id INTEGER,
        title VARCHAR(255) NOT NULL,
        title_en VARCHAR(255),
        description TEXT,
        description_en TEXT,
        slug VARCHAR(300) UNIQUE,
        specifications TEXT,
        images TEXT,
        stock_qty INTEGER NOT NULL,
        min_order_qty INTEGER DEFAULT 1,
        price_domestic DECIMAL(10,2),
        price_international DECIMAL(10,2),
        currency VARCHAR(10) DEFAULT 'CNY',
        display_domestic INTEGER DEFAULT 1,
        display_overseas INTEGER DEFAULT 1,
        expire_date DATE,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        approved_at DATETIME,
        created_by VARCHAR(20) NOT NULL,
        updated_by VARCHAR(20) NOT NULL,
        synced_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`);

      // 询盘表
      db.run(`CREATE TABLE IF NOT EXISTS inquiries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        buyer_id INTEGER NOT NULL,
        buyer_company_name VARCHAR(200),
        buyer_name VARCHAR(100),
        buyer_email VARCHAR(100),
        buyer_phone VARCHAR(50),
        product_ids TEXT,
        product_details TEXT,
        message TEXT,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        buyer_viewed_at DATETIME,
        merchant_reply TEXT,
        merchant_viewed_at DATETIME,
        last_activity_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`);

      // 订单表
      db.run(`CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_no VARCHAR(32) UNIQUE NOT NULL,
        buyer_id INTEGER NOT NULL,
        merchant_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        quantity INTEGER DEFAULT 1,
        unit_price DECIMAL(10,2) NOT NULL,
        total_amount DECIMAL(12,2) NOT NULL,
        currency VARCHAR(10) DEFAULT 'CNY',
        payment_status VARCHAR(20) NOT NULL DEFAULT 'pending_deposit',
        deposit_amount DECIMAL(10,2) DEFAULT 0,
        deposit_paid_at DATETIME,
        balance_paid_at DATETIME,
        shipping_method VARCHAR(50),
        tracking_number VARCHAR(100),
        carrier VARCHAR(100),
        shipping_address TEXT,
        shipping_cost DECIMAL(10,2) DEFAULT 0,
        status VARCHAR(20) NOT NULL DEFAULT 'pending_deposit',
        order_notes TEXT,
        created_by VARCHAR(20) NOT NULL,
        updated_by VARCHAR(20) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`, (err) => {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
  });
};

// 插入初始数据
const insertInitialData = () => {
  return new Promise((resolve, reject) => {
    const categories = [
      { name: '电子元器件', name_en: 'Electronic Components', slug: 'electronic-components', description: '各类电子元器件', level: 1, sort_order: 1 },
      { name: '集成电路', name_en: 'Integrated Circuits', slug: 'integrated-circuits', description: 'IC芯片、处理器等', level: 2, sort_order: 1 },
      { name: '被动元件', name_en: 'Passive Components', slug: 'passive-components', description: '电阻、电容、电感等', level: 2, sort_order: 2 },
      { name: '连接器', name_en: 'Connectors', slug: 'connectors', description: '各类连接器和插头', level: 2, sort_order: 3 },
      { name: '工业设备', name_en: 'Industrial Equipment', slug: 'industrial-equipment', description: '工业生产设备', level: 1, sort_order: 2 },
      { name: '自动化设备', name_en: 'Automation Equipment', slug: 'automation-equipment', description: '自动化生产线设备', level: 2, sort_order: 1 },
      { name: '机械设备', name_en: 'Machinery Equipment', slug: 'machinery-equipment', description: '各类机械加工设备', level: 2, sort_order: 2 },
    ];

    const insert = db.prepare('INSERT OR IGNORE INTO categories (name, name_en, slug, description, level, sort_order) VALUES (?, ?, ?, ?, ?, ?)');
    
    let completed = 0;
    categories.forEach(cat => {
      insert.run(cat.name, cat.name_en, cat.slug, cat.description, cat.level, cat.sort_order, (err) => {
        if (err) reject(err);
        completed++;
        if (completed === categories.length) {
          insert.finalize();
          resolve();
        }
      });
    });
  });
};

// 验证数据
const verifyData = () => {
  return new Promise((resolve, reject) => {
    db.all('SELECT id, name, name_en, slug FROM categories LIMIT 5', (err, rows) => {
      if (err) {
        reject(err);
      } else {
        console.log('\n📊 类目数据验证:');
        rows.forEach(row => {
          console.log(`  - ${row.id}: ${row.name} (${row.name_en}) - ${row.slug}`);
        });
        resolve();
      }
    });
  });
};

// 主流程
async function main() {
  try {
    console.log('\n📝 创建数据库表...');
    await createTables();
    console.log('   ✅ 表创建成功');

    console.log('\n📝 插入初始数据...');
    await insertInitialData();
    console.log('   ✅ 数据插入成功');

    await verifyData();

    console.log('\n🎉 数据库初始化完成！');

    const fs = require('fs');
    const stats = fs.statSync(dbPath);
    console.log(`\n📊 数据库大小: ${(stats.size / 1024).toFixed(2)} KB`);

    db.close();
    process.exit(0);
  } catch (error) {
    console.error('\n❌ 初始化失败:', error);
    db.close();
    process.exit(1);
  }
}

main();
